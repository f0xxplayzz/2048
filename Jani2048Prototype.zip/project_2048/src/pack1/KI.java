package pack1;

public interface KI {
	//Interface f�r alle KIs
	public Tile[][] createTile(Tile[][] t);//Methode wird von jeder KI ben�tigt, da jede KI Felder erzeugen muss
}

package pack1;

import java.util.Random;

public class RandomKI implements KI {
	//Klasse der randomisierten KI, implementiert Interface KI, erzeugt randomisert neue Felder im Spielfeld
	private boolean finished =false;//Pr�fvariable
	Random random=new Random();//Zur Erstellung von Zufallszahlen
	RandomKI(){
		
	}
	@Override
	public Tile[][] createTile(Tile[][] t,int greatestTile) {//Man �bergibt nur inneren Teil des Spielfeldes(Feld an sich)
		int x;
		int y;
		int level;
		int base =(int)(Math.pow(greatestTile, 2)*0.01+1);
		while(!finished ) {//Schleife wird erst verlassen wenn Tile gesetzt wurde
			x = random.nextInt(4);
			y = random.nextInt(4);//Erzeugt zuf�llige Indizes f�r H�he und Breite
			if(t[y][x]==null) {//Wenn an der Stelle x,y kein Tile vorliegt wird eines gesetzt
				int k= random.nextInt(10);
				if (k<8) {
					level=base +0;
				}
				else
					level=base+1;
				t[y][x]= new Tile(level);
				finished=true;//PR�fvariable auf true setzen
			}
		}
		finished= false;//R�cksetzen der Variable
		return t;//ausgeben des neuen Feldes
	}

}

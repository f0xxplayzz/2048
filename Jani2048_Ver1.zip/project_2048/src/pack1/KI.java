package pack1;

public interface KI {
	//Interface f�r alle KIs
	public int[] createTile(Field f);//Methode wird von jeder KI ben�tigt, da jede KI Felder erzeugen muss
}
